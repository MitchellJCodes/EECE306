function Ev = E(s, r)
%E Electric Field Kernel
%   EV = EM.FIELD.E(S, R) returns the Nx3 field produced by a point source
%   or a set of point sources.
%
%   See also EM.CONST.EPS0.
%
%   Example:
%   s = em.src.pointCharge(1e-9, [0 0 0]);
%   r = randn(50, 3);
%   E = em.field.E(s, r); % returns the vector field of a point charge 
%   using 50 random sample points

% Number of sample points
N = size(r,1);

% Coulomb constant
k = 1 / (4*pi*em.const.eps0());

% Position vector
r_i = s.pos;

% N x M X 3 displacement vectors
r = reshape(r, [], 1, 3);
r_i = reshape(r_i, 1, [], 3);
R = r - r_i;

% Magnitude of displacement vector
Rmag = sqrt(sum(R.^2, 3));
tol = 1e-9;
[~, off_elem] = find(Rmag < tol);

% Singularity safeguard
if ~isempty(off_elem)
    error('ERROR: Singularity found. Offending element: #%d', off_elem(1));
end

% Total electric field contributed by all points
qw = reshape(s.q .* s.w, 1, [], 1);
E_elem = k .* qw .* R ./ (Rmag .^ 3);
E_tot = sum(E_elem, 2);
Ev = reshape(E_tot, N, 3);

end


