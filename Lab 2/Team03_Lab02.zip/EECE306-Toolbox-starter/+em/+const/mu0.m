function value = mu0()
value = 4*pi*1e-7;
end