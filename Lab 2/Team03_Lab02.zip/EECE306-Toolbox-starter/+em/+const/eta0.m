function value = eta0()
mu = em.const.mu0();
eps = em.const.eps0();
value = sqrt(mu/eps);
end