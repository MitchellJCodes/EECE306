function value = c0()
mu = em.const.mu0();
eps = em.const.eps0();
value = 1/sqrt(mu*eps);
end