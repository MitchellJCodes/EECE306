function d = fromTo(P,Q)
d = Q - P;
end