function m = mag(A)
m = sqrt(sum(A.^2, 2));
end
