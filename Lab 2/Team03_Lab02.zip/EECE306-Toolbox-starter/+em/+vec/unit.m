function u = unit(A)
m = em.vec.mag(A);
u = A ./ m;
end