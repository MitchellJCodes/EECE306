function theta = angle(A,B)
dotAB = sum(A .* B, 2);
magA = em.vec.mag(A);
magB = em.vec.mag(B);
x = dotAB ./ (magA .* magB);
x = max(-1, min(1,x));
theta = acos(x);
end