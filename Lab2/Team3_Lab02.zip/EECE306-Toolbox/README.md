## EECE 306 Toolbox, team starter

Rename this folder to `EECE306-Toolbox` and keep it under version control or in
a dated backup. Everything you build this semester lives here.

## Layout

```
EECE306-Toolbox/
├── +em/          the toolbox package, one subfolder per module
├── tests/        your test files, test\\\\\\\_lab01.m onward
├── runTests.m    the test runner, provided, do not modify
└── README.md     this file, replace with your own documentation
```

## First steps

1. Put the folder containing `+em` on the Octave path with `addpath`. Do **not** add `+em` itself.
2. Delete each `CONTENTS.m` placeholder as you add real functions to that module.
3. Run `runTests` from the toolbox root. With no functions written yet it will
report a failure, which is the correct starting state.

## What to put in this README by the end of the semester

Team name and members, a one line description of every module, and a short
example showing somebody else how to compute a field with your library.
The engineering quality portion of the grade is assessed partly by whether
another team could use your toolbox from this file alone.

## Team 3 - Amelia and Carissa

## Module Descriptions

Constant Functions
* c0 = em.const.c0() - returns the scalar value of the speed of light c. 
  Note: This constant is computed from eps0 and mu0.
* e0 = em.const.eps0() - returns the scalar value of the electric constant 
  epsilon_0 (permittivity of free space).
* eta = em.const.eta0() - returns the scalar value of the intrinsic 
  impedance of free space eta (eta_0). Note: This constant is
  computed from eps0 and mu0.
* m0 = em.const.mu0() - returns the scalar value of the magnetic constant 
  mu_0 (permeability of free space).

Coordinate Functions (Point Conversion)
  Note: 0 <= phi < 2pi and 0 <= theta <= pi
* p = em.coord.c2cyl(r) - returns the corresponding Nx3 cylindrical 
  coordinate (rho, phi, z) of an Nx3 Cartesian coordinate (x, y, z); takes 
  an Nx3 Cartesian coordinate input.
* r = em.coord.cyl2c(p) - returns the corresponding Nx3 Cartesian 
  coordinate (x, y, z) of an Nx3 cylindrical coordinate (rho, phi, z); 
  takes an Nx3 cylindrical coordinate input.
* s = em.coord.c2sph(r) - returns the corresponding Nx3 spherical 
  coordinate (r, theta, phi) of an Nx3 Cartesian coordinate (x, y, z); 
  takes an Nx3 Cartesian coordinate input.
* r = em.coord.sph2c(s) - returns the corresponding Nx3 Cartesian 
  coordinate (x, y, z) of an Nx3 spherical coordinate (r, theta, phi); 
  takes an Nx3 spherical coordinate input.

Coordinate Functions (Vector Component Conversion)
* Ac = em.coord.vecC2Cyl(A, r) - returns the corresponding Nx3 cylindrical 
  vector components (A_rho, A_phi, A_z) of an Nx3 Cartesian component set
  (A_x, A_y, A_z) along an Nx3 vector in the Cartesian plane; takes an 
  array of Nx3 Cartesian vector components and an Nx3 Cartesian position.
* A = em.coord.vecCyl2C(Ac, r) - returns the corresponding Nx3 Cartesian
  vector components (A_x, A_y, A_z) of a set of Nx3 cylindrical vector
  component (A_rho, A_phi, A_z) along an Nx3 vector in the Cartesian plane;
  takes an array of Nx3 cylindrical vector components and an Nx3 Cartesian
  position.
* As = em.coord.vecC2Sph(A, r) - returns the corresponding Nx3 spherical 
  vector components (A_r, A_theta, A_phi) of an Nx3 Cartesian component set
  (A_x, A_y, A_z) along an Nx3 vector in the Cartesian plane; takes an 
  array of Nx3 Cartesian vector components and an Nx3 Cartesian position.
* A = em.coord.vecSph2C(As, r) - returns the corresponding Nx3 Cartesian
  vector components (A_x, A_y, A_z) of a set of Nx3 spherical vector
  component (A_r, A_theta, A_phi) along an Nx3 vector in the Cartesian
  plane; takes an array of Nx3 cylindrical vector components and an Nx3 
  Cartesian position.

Vector Functions
* th = em.vec.angle(A, B) - returns the Nx1 interior angle theta between 
  two Nx3 vectors A and B (in radians); takes two Nx3 vector inputs. 
  Note: cos(theta) is clamped to [-1, 1]
* d = em.vec.fromTo(P, Q) - returns the Nx3 displacement vector d (= Q - P)
  between two Nx3 vectors P and Q; takes two Nx3 vector inputs.
* m = em.vec.mag(A) - returns the Nx1 magnitude |A| of an Nx3 vector A; 
  takes an Nx3 vector input.
* u = em.vec.unit(A) - returns the normalized Nx3 vector of a non-zero Nx3
  vector (a zero vector returns NaN in all directions); takes an Nx3 vector
  input. Note: a zero vector input will return rows of NaN, due to divison 
  by 0.

## Helpful Notes
* An NxM vector has N rows and M columns (Ex: an Nx1 vector has an 
  arbitrary number of rows N and one column)
* NaN means "Not a Number", which is a shorthand for indeterminate and 
  undefined values such as 0/0.

